require('util').inherits(module.exports, require(require('path').join(GLOBAL.ROOTDIR, 'core', 'module.js')));

module.exports.prototype.init = function(){
	this.log.write('Initializing...', '', 4);
	this.emit('hello', {name: 'Jacob'});
}

module.exports.prototype.close = function(){
}