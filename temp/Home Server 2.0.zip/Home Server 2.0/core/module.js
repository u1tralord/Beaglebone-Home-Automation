var events = require('events');

module.exports = function(){
	events.EventEmitter.call(this);
}
require('util').inherits(module.exports, events.EventEmitter);